
#ifndef TORRENT_STORAGE_HPP_INCLUDED
#define TORRENT_STORAGE_HPP_INCLUDED

#error "the disk I/O subsystem has been overhauled in libtorrent 2.0. storage_interface is no longer a customization point, customize disk_interface instead"

#endif
